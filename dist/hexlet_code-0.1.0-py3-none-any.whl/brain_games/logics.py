def first_round
def second_round
def third_round

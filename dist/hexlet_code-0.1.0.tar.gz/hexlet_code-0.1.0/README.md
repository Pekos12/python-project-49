### Hexlet tests and linter status:
[![Actions Status](https://github.com/Pekos12/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Pekos12/python-project-49/actions)
<a href="https://codeclimate.com/github/Pekos12/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c4760e581c01c3f91939/maintainability" /></a>

testing brain-even game: https://asciinema.org/a/kG4v3PZnsfkPG3Ovyqw9ATZuw

testing brain-calc game: https://asciinema.org/a/k7eePUNb0ahrqeM9jmSuASuCS

testing brain-gcd game: https://asciinema.org/a/drGvkVQbVsmS30hfFRiMcgpRU

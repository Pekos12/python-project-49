### Hexlet tests and linter status:
[![Actions Status](https://github.com/Pekos12/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Pekos12/python-project-49/actions)
<a href="https://codeclimate.com/github/Pekos12/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c4760e581c01c3f91939/maintainability" /></a>
